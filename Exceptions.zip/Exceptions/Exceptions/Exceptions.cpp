// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept>
#include <exception>
#include <string>

// FIXED: Custom exception class
class CustomException : public std::exception {
private:
    std::string message;

public:
    CustomException(const std::string& msg) : message(msg) {}

    const char* what() const noexcept override {
        return message.c_str();
    }
};
// ENDFIX

bool do_even_more_custom_application_logic()
{
    // FIXED: Throw any standard exception
    throw std::runtime_error("Error in even more custom application logic.");
    // ENDFIX
    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}
void do_custom_application_logic()
{
    // FIXED: Wraps the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing
    std::cout << "Running Custom Application Logic." << std::endl;

    try {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& e) {
        std::cout << "Caught exception: " << e.what() << std::endl;
    }
    // ENDFIX

    // FIXED: Throws a custom exception derived from std::exception
    //  and catch it explictly in main
    throw CustomException("Custom exception from do_custom_application_logic.");

    std::cout << "Leaving Custom Application Logic." << std::endl;
    // ENDFIX

}

float divide(float num, float den)
{
    // FIXED: Throws an exception to deal with divide by zero errors using
    //  a standard C++ defined exception
    if (den == 0.0f) {
        throw std::invalid_argument("Divide by zero error.");
    }
    return (num / den);
}
// ENDFIX

void do_division() noexcept
{
    //  FIXED: Creates an exception handler to capture ONLY the exception thrown
    //  by divide.

    float numerator = 10.0f;
    float denominator = 0;

    try {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::invalid_argument& e) {
        std::cout << "Division exception: " << e.what() << std::endl;
    }
}
//ENDFIX

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    // FIXED: Creates exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception 
    //  that wraps the whole main function, and displays a message to the console.
    try {
        do_division();
        do_custom_application_logic();
    }
    catch (const CustomException& e) {
        std::cout << "Custom exception caught: " << e.what() << std::endl;
    }
    catch (const std::exception& e) {
        std::cout << "Standard exception caught: " << e.what() << std::endl;
    }
    catch (...) {
        std::cout << "Unknown exception caught." << std::endl;
    }
}
// ENDFIX   

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu